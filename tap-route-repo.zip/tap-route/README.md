<p align="center">
  <img src="docs/images/hero.png" alt="Tap Route on three phones: the skill map, a game plan flowchart and the stats radar" width="100%">
</p>

<p align="center">
  <img alt="No account" src="https://img.shields.io/badge/account-none-2F6B2F?style=flat-square">
  <img alt="Works offline" src="https://img.shields.io/badge/offline-ready-2F6B2F?style=flat-square">
  <img alt="Installable" src="https://img.shields.io/badge/PWA-installable-2F6B2F?style=flat-square">
  <img alt="No build step" src="https://img.shields.io/badge/build_step-none-8A6B48?style=flat-square">
  <img alt="Zero dependencies" src="https://img.shields.io/badge/dependencies-0-8A6B48?style=flat-square">
  <img alt="Your data stays on your device" src="https://img.shields.io/badge/data-stays_on_your_device-8A6B48?style=flat-square">
</p>

<p align="center">
  <b>A practice journal for Brazilian jiu-jitsu.</b><br>
  Map what you know, log every class, watch yourself grow, and build a game plan you can actually drill.
</p>

<p align="center">
  <a href="docs/USER_GUIDE.md">User guide</a> (<a href="docs/Tap-Route-User-Guide.pdf">PDF</a>) ·
  <a href="#get-it-running">Get it running</a> ·
  <a href="#how-the-numbers-work">How the numbers work</a> ·
  <a href="#under-the-hood">Under the hood</a>
</p>

---

## Why Tap Route

Most of jiu-jitsu disappears between classes. You learn a sweep on Tuesday, you cannot remember the grip by Saturday, and a month later you could not say whether you are getting better at anything.

Tap Route is a pocket-sized training notebook that fixes that in about two minutes after class. It is built around a simple idea: **your game is a tree of positions and the moves that connect them**, so the app shows it as one.

- **See it.** A map of 12 positions and 217 techniques, colored by how confident you feel.
- **Log it.** Two taps and a few lines after class. No forms to fight.
- **Grow it.** A timeline that shows practices, level-ups, goals you finished and tournaments you entered.
- **Plan it.** A guided builder that turns "where does the match start for me?" into a flowchart of attacks and answers, then tells you what to drill at open mat.

It runs in your phone's browser, installs to your home screen, works offline, and keeps everything on your device.

---

## What it looks like

<table>
  <tr>
    <td align="center" width="25%"><img src="docs/images/map.png" alt="Skill map" width="100%"><br><sub><b>Skill map</b><br>Rings show moves seen, color shows confidence</sub></td>
    <td align="center" width="25%"><img src="docs/images/position.png" alt="A position's techniques" width="100%"><br><sub><b>Every position</b><br>Top and bottom, grouped by type</sub></td>
    <td align="center" width="25%"><img src="docs/images/technique.png" alt="Technique sheet" width="100%"><br><sub><b>Rate a move</b><br>Level, confidence, notes, videos</sub></td>
    <td align="center" width="25%"><img src="docs/images/log.png" alt="Practice log" width="100%"><br><sub><b>Log a class</b><br>Search, tap, jot a note</sub></td>
  </tr>
  <tr>
    <td align="center" width="25%"><img src="docs/images/timeline.png" alt="Timeline" width="100%"><br><sub><b>Timeline</b><br>Practices per week at a glance</sub></td>
    <td align="center" width="25%"><img src="docs/images/journey.png" alt="Journey" width="100%"><br><sub><b>Your journey</b><br>Practices, level-ups, milestones</sub></td>
    <td align="center" width="25%"><img src="docs/images/builder-3.png" alt="Guided game plan builder" width="100%"><br><sub><b>Guided game plan</b><br>Suggested reactions for every move</sub></td>
    <td align="center" width="25%"><img src="docs/images/flowchart.png" alt="Game plan flowchart" width="100%"><br><sub><b>Flowchart</b><br>Step color is your confidence</sub></td>
  </tr>
  <tr>
    <td align="center" width="25%"><img src="docs/images/openmat.png" alt="Open mat focus" width="100%"><br><sub><b>Open mat focus</b><br>What needs reps, ranked</sub></td>
    <td align="center" width="25%"><img src="docs/images/stats.png" alt="Stats radar" width="100%"><br><sub><b>Stats</b><br>Seven skills on one radar</sub></td>
    <td align="center" width="25%"><img src="docs/images/map-dark.png" alt="Dark mode map" width="100%"><br><sub><b>Dark mode</b><br>Follows your phone</sub></td>
    <td align="center" width="25%"><img src="docs/images/stats-dark.png" alt="Dark mode stats" width="100%"><br><sub><b>Built for the mat bag</b><br>Readable in a dim gym</sub></td>
  </tr>
</table>

<sub>Screenshots use sample data.</sub>

---

## Features

### Map
- **12 positions, 217 techniques**, from Base and Leverage and Standup through every guard to Side Control, Knee on Belly, Mount and Back.
- **Progress rings** show how many moves you have seen in each position. The circle shows your **average confidence**, from tan (shaky) to deep green (solid).
- **Gi, no-gi or both.** One switch filters the whole app. Moves that only work in the gi are marked.
- **Fast search** with short codes: type `rnc`, `kob` or `dlr` and get what you meant.
- **Move sheet** with a level (New, Seen, Drilled, Tested), a confidence rating out of 10, gi or no-gi, last practiced date, personal notes, and one-tap YouTube searches for the move.
- **A daily quote** from martial arts teachers, because a map is more fun with a reason to open it.

### Log
- Pick the date, gi or no-gi, search for the moves you worked on, set a level and confidence for each, and write what clicked.
- **Rating is not practicing.** Rating a move you already know does not log a practice, so your timeline only counts the classes you actually attended.

### Timeline
- **Practices per week** for the last 12 weeks, with a table view for screen readers.
- **Goals that count themselves.** Write "go to practice 3 times this week" and the progress bar fills from your log.
- **Your journey**: every practice, level-ups, rating changes, goals you finished, milestones (your first practice, then 10, 25, 50, 100 and 200) and tournaments.
- **Average confidence stays hidden until every area of the map has at least one rated move**, so the number means something when it appears.
- *Optional, Claude only:* tag the themes in your notes and summarize trends. These buttons stay hidden in the standalone site.

### Plan
- **Competition countdown** with your tournament name, date and rules.
- **A three-step guided builder.** Pick where the match starts for you, pick one to three moves you like from there, then tap the suggested reactions ("They post a hand to stop the bump") and what you do next. Out comes a flowchart.
- **Check this plan** flags steps that rest on low-rated or unrated moves, and gi grips in a no-gi plan.
- **Open mat focus** ranks the moves in your plans by how much they need reps: unrated, low confidence, or not drilled in 21 days. Tick what you want, then send it to your log.

### Stats
- **Seven skills** (Submissions, Sweeps, Takedowns, Passing, Transitions, Escapes, Defense) on a radar, rolled up into **Attack, Control and Defense** and an **Overall** score.
- **Signature moves**: your five highest-rated techniques.
- **Gi vs no-gi** comparison, so you can see which side of your game lags.

---

## How the numbers work

Nothing here is a black box.

| Number | How it is calculated |
|---|---|
| **Position circle** | The average of your 1 to 10 confidence ratings on the moves you have rated in that position. Unrated moves do not count. |
| **Ring** | Moves at level Seen or higher, out of all moves in that position. |
| **Skill score (0 to 100)** | Take your **five highest-rated moves** in that skill, add their ratings, divide by 50. Empty slots count as zero. Passing moves rated 8, 7, 6, 4 and 3 add up to 28, so Passing is **56**. |
| **Attack, Control, Defense** | Attack is the average of Submissions, Sweeps and Takedowns. Control is Passing and Transitions. Defense is Escapes and Defense. |
| **Overall** | The average of all seven skills. |
| **Average confidence** | Shown only once every position on the map has at least one rated move. |

Confidence colors run on a single tan-to-green lightness ramp, and every circle, chip and flowchart step also prints its number, so color is never the only signal.

---

## Get it running

Tap Route is plain HTML, CSS and JavaScript. There is nothing to install and nothing to build.

### Host it (free, about five minutes)

**GitHub Pages**

1. Push this repository to GitHub.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, pick `main` and `/ (root)`, and save.
4. Open the link GitHub gives you on your phone.

**Or drag and drop.** Netlify Drop (`app.netlify.com/drop`) and Cloudflare Pages both take this folder as it is.

### Put it on your home screen

- **iPhone (Safari):** Share → **Add to Home Screen**
- **Android (Chrome):** menu → **Install app**

### Run it locally

```bash
git clone <your-repo-url>
cd tap-route
python3 -m http.server 8000
# open http://localhost:8000
```

Any static file server works. Opening `index.html` straight from disk also works, but the offline cache and home screen install need `http://` or `https://`.

---

## Under the hood

| | |
|---|---|
| **Stack** | Vanilla JavaScript, one HTML file (about 195 KB), no framework, no bundler, no runtime dependencies |
| **Storage** | `localStorage` in the browser. Writes are immediate and the app works with no connection |
| **Offline** | A small service worker caches the app. It fetches fresh files first and falls back to the cache, so updates arrive without a version bump |
| **Install** | Web app manifest plus icons, so it installs like a native app on iOS and Android |
| **Design** | Mobile first, light and dark themes from the same tokens, bottom tab bar, bottom sheets for editing |
| **Fonts** | Barlow, Big Shoulders Display and IBM Plex Mono from Google Fonts, with system fallbacks |
| **Accessibility** | Labelled controls, visible focus, text alternatives for charts, and a table view for the weekly chart |

### Project layout

```text
tap-route/
├── index.html              the whole app
├── manifest.webmanifest    install metadata
├── sw.js                   offline cache
├── icon-192.png            app icons
├── icon-512.png
├── apple-touch-icon.png
├── .nojekyll               tells GitHub Pages to serve files as they are
└── docs/
    ├── USER_GUIDE.md       guide for new users
    ├── Tap-Route-User-Guide.pdf   printable copy of the guide
    └── images/             screenshots used in the docs
```

---

## Your data

- Everything you enter is saved **in your browser, on your device**. There is no account, no server and no analytics.
- That also means it is **not synced**. A new phone, a new browser, or clearing site data starts you fresh.
- Nobody else, including your coach or teammates, can see your log unless you show them your screen.

---

## Ideas on the list

These are ideas, not promises.

- Export and import a backup file, so moving phones keeps your history
- Optional sync across devices
- A coach view for a team that opts in
- More positions and techniques as the map grows

Have a suggestion? Open an issue.

---

## A note

Tap Route is an independent, student-built project. It is not affiliated with or endorsed by any academy, instructor, or video service it mentions or links to. Technique videos open as searches on YouTube. If your academy has its own video library, check that you are allowed to link to it before sharing a public copy.

Built by Aryan, a white belt, for his own training. Oss.
