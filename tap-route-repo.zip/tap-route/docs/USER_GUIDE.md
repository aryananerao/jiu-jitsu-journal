# Tap Route: User Guide

A practice journal for Brazilian jiu-jitsu. Map what you know, log your classes, watch yourself grow, and build a game plan you can drill.

**In one minute:** open Tap Route on your phone, rate the moves you already know on the Map, then log each class after you train. The Timeline, Stats and Plan pages fill in on their own.

<p align="center"><img src="images/map.png" alt="The Tap Route map" width="300"></p>

---

## Contents

1. [Get it on your phone](#1-get-it-on-your-phone)
2. [Your first five minutes](#2-your-first-five-minutes)
3. [A tour of the five pages](#3-a-tour-of-the-five-pages)
4. [Building a game plan, step by step](#4-building-a-game-plan-step-by-step)
5. [How the numbers work](#5-how-the-numbers-work)

---

## 1. Get it on your phone

You open Tap Route from a link, like a website. Putting it on your home screen makes it feel like an app: its own icon, full screen, and it still opens at the gym with no signal.

**iPhone (Safari)**

1. Open the Tap Route link in Safari.
2. Tap the **Share** button.
3. Tap **Add to Home Screen**, then **Add**.

**Android (Chrome)**

1. Open the Tap Route link in Chrome.
2. Tap the **menu** (three dots).
3. Tap **Install app** (or **Add to Home screen**).

Tap Route follows your phone's light or dark setting.

> **Use the same browser every time.** Your log is saved inside the browser or home screen app you set it up in, on that phone only. It is not synced, so a new phone, a different browser or cleared site data starts you fresh.

---

## 2. Your first five minutes

You do not need to fill in anything before it is useful. A good first session looks like this.

**Step 1. Rate a few moves you already know.**
Open the **Map** and tap a position you train a lot, like Closed Guard. Tap a move, then set:

- **How far along:** New, Seen, Drilled or Tested.
- **Confidence out of 10:** how sure you feel about it right now.

Ten or fifteen moves is plenty to start.

**Step 2. Log your next class.**
Go to **Log**, search for the moves you worked on, and write a line or two about what clicked or what did not. Tap **Save practice**.

**Step 3. Peek at the Timeline.**
You will see your first practice, a bar in the weekly chart, and the start of your journey.

<p align="center"><img src="images/technique.png" alt="Rating a move" width="260">&nbsp;&nbsp;<img src="images/log.png" alt="Logging a class" width="260"></p>

> **Rating is not the same as practicing.** Rating a move tells Tap Route how sure you feel about it. It does **not** log a practice. Only the Log page counts a class, so your practice count stays honest.

---

## 3. A tour of the five pages

The bar at the bottom switches between pages.

### Map

Your whole game on one screen: 12 positions and 217 techniques.

- The **ring** around a position shows how many of its moves you have seen.
- The **number and color** inside show your average confidence there, from tan (shaky) to deep green (solid). A dash means you have not rated anything there yet.
- Use the **Gi and no-gi / Gi / No-gi** buttons to filter everything.
- Use **Find a technique** at the top of any page. Short codes work: `rnc`, `kob`, `dlr`.
- Tap a position to see its moves grouped by type, with **Top** and **Bottom** where it matters. Each row shows three dots for how far along you are and your confidence rating on the right.
- Tap a move to open its sheet: level, confidence, gi or no-gi, last practiced, notes, and links that search YouTube for the move.

<p align="center"><img src="images/position.png" alt="A position's moves" width="260">&nbsp;&nbsp;<img src="images/map-dark.png" alt="Map in dark mode" width="260"></p>

Each day the Map also shows a short quote from a martial arts teacher.

### Log

Record each class in about a minute.

1. Check the **date** and choose **Gi** or **No-gi**.
2. Search **What did you work on?** and tap a result to add it. Add as many as you like.
3. For each move, set a **Level** and **Confidence**, or leave confidence on **Keep** to leave your rating alone.
4. Write **Notes**: what clicked, what did not, questions for your coach.
5. Tap **Save practice**.

Recent practices appear underneath. Tap **×** twice on one to delete it.

> Only add moves from that class. To rate a move you know from before, open it on the Map instead.

### Timeline

How you are growing, in four parts.

<p align="center"><img src="images/timeline.png" alt="Timeline" width="260">&nbsp;&nbsp;<img src="images/goals.png" alt="Goals" width="260">&nbsp;&nbsp;<img src="images/journey.png" alt="Journey" width="260"></p>

- **Top tiles and the weekly chart.** Practices logged, techniques seen, and a bar for each of the last 12 weeks. Tap a bar for that week, or open **View as table**.
- **Average confidence** appears once every area of the map has at least one rated move. Until then the Timeline tells you how many areas are left.
- **Trends in your notes.** When Tap Route runs inside Claude, it can tag the themes in your notes and summarize them. In the standalone version this part stays quiet.
- **My goals.** Write a goal in your own words. If it names a weekly practice target, like **Go to practice 3 times this week**, the bar fills itself from your log and says when you are done for the week. Other goals get a checkbox, and finishing one puts it on your journey.
- **Your journey.** A running story of your practices, level-ups, rating changes, goals you finished, milestones (your first practice, then 10, 25, 50, 100 and 200) and tournaments.

### Plan

Turn "what should I work on?" into a plan.

- **Competing soon?** Add a tournament name, date and rules, and the page shows a countdown. The Map shows a small countdown pill too.
- **Build your game plan.** A three-step guide, covered in the next section.
- **Your game plans.** Every plan you have built. Tap one to see its flowchart.
- **Open mat focus.** The moves in your plans that need the most reps, ranked. Tick the ones you want to drill, then tap **Log this open mat** to send them to your log.
- **Reset game plans** deletes all your plans after a second tap. Your ratings and logs are kept.

### Stats

Seven skills on one radar: Submissions, Sweeps, Takedowns, Passing, Transitions, Escapes and Defense.

<p align="center"><img src="images/stats.png" alt="Stats radar" width="260">&nbsp;&nbsp;<img src="images/skills.png" alt="Skills list" width="260"></p>

- The four tiles at the top roll the skills up into **Overall**, **Attack**, **Control** and **Defense**.
- **Skills** lists each one with your best move in it. Tap a skill to see the five moves that make up its score and which ones to rate next.
- **Signature moves** are your five highest-rated techniques.
- **Gi vs no-gi** shows whether one side of your game is lagging.

---

## 4. Building a game plan, step by step

A game plan is a small flowchart: where the match starts for you, what you attack with, what your partner might do about it, and what you do next. You do not need to know that in advance. The guide suggests it.

Open **Plan** and tap **Start building**.

**Step 1 of 3: Where does the match start for you?**
Choose gi, no-gi or both, then tap your starting point, such as **My closed guard** or **Inside their closed guard**.

**Step 2 of 3: Which moves do you want to hit from here?**
Pick one to three. The top three are suggestions, and a move you rate highly is flagged. **More moves from here** lists everything else.

**Step 3 of 3: What might they do about it?**
For each move you picked, Tap Route lists the common reactions, like *They post a hand to stop the bump*. Tap the answers you want in your plan. There is also **If it works**, for what you do next once the move lands. Tap **Next move** until you are done.

<p align="center"><img src="images/builder-1.png" alt="Step 1: where the match starts" width="230">&nbsp;&nbsp;<img src="images/builder-2b.png" alt="Step 2: pick your moves" width="230">&nbsp;&nbsp;<img src="images/builder-3.png" alt="Step 3: reactions" width="230"></p>

When you finish, you see your plan as an outline. Tap **See the flowchart** to view it, or **Go one level deeper** to add another layer of reactions.

<p align="center"><img src="images/flowchart.png" alt="A game plan flowchart" width="260">&nbsp;&nbsp;<img src="images/openmat.png" alt="Open mat focus" width="260"></p>

In the flowchart:

- **Step color is your confidence**, from tan (weak) to deep green (strong). Grey means unrated or a custom step.
- Tap a **step** to add what happens next. Tap a **label** to edit it.
- Use **+** and **−** to zoom.
- **Check this plan** at the bottom points out steps built on low-rated or unrated moves.

The plan then feeds **Open mat focus** on the Plan page, so you know what to drill.

> The suggested reactions are a starting point built from common jiu-jitsu patterns. Your coach is the best judge of what works for your game, so ask them to look over your plan.

---

## 5. How the numbers work

| What you see | How it is calculated |
|---|---|
| **Position circle (Map)** | Average of your 1 to 10 ratings on the moves you have rated in that position. Unrated moves do not count. |
| **Ring (Map)** | Moves at Seen or higher, out of all moves in that position. |
| **Skill score, 0 to 100 (Stats)** | Your **five highest-rated moves** in that skill, added up, divided by 50. Empty slots count as zero. |
| **Attack** | Average of Submissions, Sweeps and Takedowns. |
| **Control** | Average of Passing and Transitions. |
| **Defense** | Average of Escapes and Defense. |
| **Overall** | Average of all seven skills. |
| **Average confidence (Timeline)** | Shown once every position has at least one rated move. |

**Example.** Your five best Passing moves are rated 8, 7, 6, 4 and 3. That adds up to 28, and 28 ÷ 50 is 56, so Passing shows **56**. If you have only rated three passes, the other two slots count as zero. Rate more passes, or improve the ones you have, and the number rises.

**The four levels**

| Level | Meaning |
|---|---|
| **New** | Not learned yet. |
| **Seen** | You have seen it in class or on video. |
| **Drilled** | You can do it with a cooperative partner. |
| **Tested** | It works against a partner who resists. |

**A simple way to think about confidence**

| Rating | Feels like |
|---|---|
| 1 to 2 | Shaky. You need the steps in front of you. |
| 3 to 4 | Still learning. It works when everything lines up. |
| 5 to 6 | Works sometimes in live rolling. |
| 7 to 8 | Reliable. You expect it to work. |
| 9 to 10 | A go-to. You hit it under pressure. |

Rate the way you feel today, and re-rate as you improve. Your Timeline shows when a rating jumps.

---

*Tap Route is an independent, student-built project. It is not affiliated with or endorsed by any academy, instructor or video service it mentions or links to.*
